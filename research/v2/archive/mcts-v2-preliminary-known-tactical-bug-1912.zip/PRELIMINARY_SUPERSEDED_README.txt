Superseded preliminary V2 data. Do not include these records in final statistics.

At 2026-10-18, a tactical correctness review found that the pre-correction D2 one-ply scanner accumulated stones across different Gomoku directions. This could create false immediate wins or forced blocks. The original run used code commit 0916f3fa7c10c21805376a4e27fef7c1286dd971. All D2-involved records are retained here for audit only and were removed from the active formal dataset for rerun under the corrected implementation. A/B/C/D1 records are unaffected and were retained in the active dataset.
